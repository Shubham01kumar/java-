import java.util.Scanner;

public class CompoundInterestCalculator {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Taking input from the user
        System.out.print("Enter Principal Amount: ");
        double principal = scanner.nextDouble();

        System.out.print("Enter Rate of Interest: ");
        double rate = scanner.nextDouble();

        System.out.print("Enter Time (in years): ");
        double time = scanner.nextDouble();

        // Calculating compound interest
        double compoundInterest = principal * Math.pow((1 + rate / 100), time);

        // Displaying the result
        System.out.println("Compound Interest: " + compoundInterest);

        scanner.close();
    }
}