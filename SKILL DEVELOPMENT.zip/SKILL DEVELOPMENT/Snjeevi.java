import java.util.Scanner;

public class Snjeevi {
    public static void main(String[] args) {
       Scanner sa = new Scanner(System.in);
       System.out.print("enter the name :");
       String name = sa.nextLine();
       System.out.println("MY name is "+name +" CSE");
       

    }
}
